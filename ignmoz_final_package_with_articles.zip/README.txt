Pacote IGN Moz — atualizado com artigos completos.
Instruções: Unzip and run a static server: python -m http.server 8000 ; open http://localhost:8000/index.html
Arquivos incluídos: index.html, artigos (.html), assets/, sitemap.xml, robots.txt
Google Analytics: substitua G-XXXXXXX nas páginas pelo seu ID (se desejar).