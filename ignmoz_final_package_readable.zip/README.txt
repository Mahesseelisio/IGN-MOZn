Pacote IGN Moz — versão final com artigos completos e leitura direta.
Instruções: extraia e rode um servidor estático (python -m http.server 8000) e abra http://localhost:8000/index.html
Substitua imagens em assets/ por imagens reais se desejar. Ative Disqus substituindo YOUR_DISQUS_SHORTNAME no código das páginas de artigo.
