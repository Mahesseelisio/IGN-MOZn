IGN Moz - repo ready for deploy.

To deploy on Vercel:
1. Create a GitHub repo and push this folder.
2. In Vercel, import the repo. Deploy will be automatic.

To deploy on Cloudflare Pages:
1. Create a GitHub repo and push this folder.
2. In Cloudflare Pages, connect to repo and deploy.
